package com.example.demo;

public class Product 
{
	private String name;
	private double netAmount;
	private boolean exempt;
	private boolean imported;
	
	public Product(String name, double netAmount, boolean exempt, boolean imported)
	{
		this.name = name;
		this.netAmount = netAmount;
		this.exempt = exempt;
		this.imported = imported;
	}
	
	public double getSaleTaxes()
	{
		double saleTaxes = 0;
		
		double taxPercent = 0;
		
		if(!exempt)
		{
			taxPercent += 10.0;
		}
		
		if(imported)
		{
			taxPercent += 5.0;
		}
		
		saleTaxes += round05((netAmount * taxPercent) / 100.0);
		
		return saleTaxes;
	}
	
	public double getTotalPrice()
	{
		double value = netAmount + getSaleTaxes();
		return Math.round(value * 100) / 100.0;
	}
	
	public double round05(double num) {
        return Math.round(num * 20) / 20.0;
	}
	
}
