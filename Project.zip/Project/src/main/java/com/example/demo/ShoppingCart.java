package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart 
{
	private List<Product> products;
	
	public ShoppingCart()
	{
		products = new ArrayList<Product>();
	}
	
	public void addProduct(Product p)
	{
		products.add(p);
	}
	
	public void printTotalAmount()
	{
		double totalTaxes = 0;
		double totalAmount = 0;
		
		for(Product p : products)
		{
			System.out.println(p.getSaleTaxes());
			System.out.println(p.getTotalPrice());
			totalTaxes += p.getSaleTaxes();
			totalAmount += p.getTotalPrice();
		}
		
		System.out.println(Math.round(totalTaxes * 100) / 100.0);
		System.out.println(Math.round(totalAmount * 100) / 100.0);
	}
}
