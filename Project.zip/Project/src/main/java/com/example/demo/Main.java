package com.example.demo;

public class Main {

	public static void main(String[] args)
	{
		ShoppingCart cart1 = new ShoppingCart();
		
		cart1.addProduct(new Product("book", 12.49, true, false));
		cart1.addProduct(new Product("music CD", 14.99, false, false));
		cart1.addProduct(new Product("chocolate bar", 0.85, true, false));
		
		cart1.printTotalAmount();
		System.out.println("======================================================");
		
		ShoppingCart cart2 = new ShoppingCart();
		
		cart2.addProduct(new Product("box of chocolates", 10.00, true, true));
		cart2.addProduct(new Product("bottle of perfume", 47.50, false, true));
		
		cart2.printTotalAmount();
		System.out.println("======================================================");
		
		ShoppingCart cart3 = new ShoppingCart();
		
		
		cart3.addProduct(new Product("bottle of perfume", 27.99, false, true));
		cart3.addProduct(new Product("bottle of perfume", 18.99, false, false));
		cart3.addProduct(new Product("packet of headache pills", 9.75, true, false));
		cart3.addProduct(new Product("box of chocolates", 11.25, true, true));
		
		cart3.printTotalAmount();

	}
}
